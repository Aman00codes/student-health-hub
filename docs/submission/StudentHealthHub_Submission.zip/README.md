# StudentHealthHub - Fluxus 2025 Submission Package

## 📁 Package Contents

1. **docs/**
   - `StudentHealthHub_Submission.md` - Main submission document
   - Technical documentation and implementation details

2. **screenshots/**
   - Application screenshots and UI demonstrations
   - System architecture diagrams

3. **code/**
   - Key code snippets and examples
   - Important implementation highlights

## 🔗 Quick Links

- **Live Demo**: [https://student-health-hub.vercel.app](https://student-health-hub.vercel.app)
- **GitHub Repository**: [https://github.com/Aman00codes/student-health-hub](https://github.com/Aman00codes/student-health-hub)
- **Video Demo**: [https://youtu.be/student-health-hub-demo](https://youtu.be/student-health-hub-demo)

## 👥 Team Members

1. **Rohan Singh** - Frontend & AI Lead
2. **Rudra Pratap Singh** - Backend & DevOps Lead
3. **Aman Kumar** - Blockchain & Security Lead

## 📧 Contact

For any queries regarding this submission, please contact:
- **Email**: team@student-health-hub.com
- **Institution**: Indian Institute of Technology (IIT), Indore
